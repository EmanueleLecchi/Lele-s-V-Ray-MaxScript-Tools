put in 
C:\Program Files\Autodesk\3ds Max 20xx\scripts\Startup\

Find the new buttons in the V-Ray lights creation tab.